package models.chitModels;

public class MoveChit extends ActionChit {

}
