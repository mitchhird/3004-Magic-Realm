package models.chitModels;

public class FightChit extends ActionChit {

}
