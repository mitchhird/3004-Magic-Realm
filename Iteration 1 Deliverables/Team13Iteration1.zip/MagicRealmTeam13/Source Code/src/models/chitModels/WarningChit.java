package models.chitModels;

public class WarningChit {

}
