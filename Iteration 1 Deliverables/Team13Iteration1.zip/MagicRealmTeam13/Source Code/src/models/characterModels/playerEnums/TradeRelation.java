package models.characterModels.playerEnums;

public enum TradeRelation {
	ENEMY,
	UNFRIENDLY,
	NEUTRAL,
	FRIENDLY,
	ALLY
}
