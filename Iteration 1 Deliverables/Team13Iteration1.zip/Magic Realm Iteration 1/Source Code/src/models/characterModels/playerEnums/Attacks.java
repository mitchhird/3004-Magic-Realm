package models.characterModels.playerEnums;

public enum Attacks {
	THRUST,
	SWING,
	SMASH
}
