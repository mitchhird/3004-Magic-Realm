package models.chitModels;

public enum ArmorType {
	ARMOUR,
	HELMET,
	SHIELD,
	BREASTPLATE;
}
